<?php


namespace Tests\Acceptance;

use Tests\Support\AcceptanceTester;

class TestCest
{
    public function _before(AcceptanceTester $I)
    {
    }

    // tests
    public function tryToTest(AcceptanceTester $I)
    {
    }
}
