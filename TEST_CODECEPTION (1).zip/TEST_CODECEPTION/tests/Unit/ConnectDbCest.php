<?php


namespace Tests\Unit;

use Tests\Support\UnitTester;

class ConnectDbCest
{
    public function _before(UnitTester $I)
    {
    }
    // tests
    public function tryToTest(UnitTester $I)
    {
    }
}
